 
select dept_no,(sum)salary as Salary_sum where Salary_sum>20000;