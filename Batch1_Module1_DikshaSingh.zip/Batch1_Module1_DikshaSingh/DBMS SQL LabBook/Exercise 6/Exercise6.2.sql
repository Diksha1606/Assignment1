insert into
customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) 
values ( 6000, John, #115 Chicago, #115 Chicago, M, 25, 7878776, 10000 );

insert into
 customermaster (customerid,'customername','address1','address2','gender',age,'phoneno)
 values (6001, Jack, #116 France, #116 France, M, 25, 434524, 20000  );

insert into 
customermaster (customerid,'customername','address1','address2','gender',age,'phoneno)
 values (6002, James, #114 New York, #114 New York, M, 45, 431525, 15000.50);

savepoint p1;