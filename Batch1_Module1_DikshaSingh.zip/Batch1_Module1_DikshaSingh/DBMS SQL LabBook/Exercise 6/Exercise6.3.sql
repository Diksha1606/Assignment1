insert into 
customermaster (customerid,'customername','address1','address2','gender',age,'phoneno)
 values (6003, John, #114 Chicago, #114 Chicago, M, 45, 439525, 19000.60);