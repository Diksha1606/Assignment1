Create table employee as select * from emp where 1=3;
select * from employee